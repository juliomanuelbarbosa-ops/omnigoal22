exports.handler = async function (event) {
  const sport = event.queryStringParameters?.sport || "soccer_epl";
  const key = process.env.ODDS_API_KEY;

  const url =
    `https://api.the-odds-api.com/v4/sports/${sport}/odds/` +
    `?apiKey=${key}&regions=uk,eu&markets=h2h&oddsFormat=decimal&dateFormat=iso`;

  try {
    const resp = await fetch(url);
    const text = await resp.text();
    return {
      statusCode: resp.status,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: text,
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: e.message }),
    };
  }
};
